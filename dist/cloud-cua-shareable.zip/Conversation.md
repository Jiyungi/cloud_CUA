Look at the hack I am in and understand what it is about, teach me how state of the art computer use agents work today and everyhting I need to know about them, what makes simple VLMs agentics? read the docuentation of H company in depth and understand deeply how to use their tools and what they are currentyl are and where their models/agents are lacking in right now:
https://hub.hcompany.ai/






Friday 10:25 PM






Worked for 3m 14s



I inspected the local hack brief in [description.md](C:\\Users\\Mr. Paul\\Downloads\\H Computer Use Hack\\readme files\\description.md) and [luma.md](C:\\Users\\Mr. Paul\\Downloads\\H Computer Use Hack\\readme files\\luma.md). This is a 48-hour H Company computer-use hackathon in San Francisco, Saturday July 11 to Sunday July 12, 2026. The core rule is simple: you must use H Company agents/models. Tracks are Computer Use, Browser Use, and Free-for-All. Judging is 20 points each for technicality, creativity, usefulness, demo, and sponsor/track alignment.
Mental Model
A plain VLM becomes “agentic” only when you put it in a closed action loop:
goal -> observe screen -> reason/plan -> emit structured action -> execute click/type/scroll/tool -> observe result -> update memory -> repeat -> final answer
The model is not the whole agent. The agent is the model plus the harness: environment, screenshots, coordinate mapping, tool dispatcher, memory, budgets, retries, logs, human steering, secrets, and verification.
Modern computer-use agents are moving from “general VLM + prompt” to “native GUI/action models.” Holo, UI-TARS, OpenAI CUA-style systems, and Claude Computer Use-style systems are trained on screen-action trajectories, UI grounding, multi-step workflows, and tool outputs. H’s own Holo3 post says their edge comes from synthetic navigation data, out-of-domain augmentation, curated RL, and synthetic enterprise environments.(hcompany.ai) UI-TARS-2 similarly frames SOTA GUI agents as unified perception, reasoning, memory, action, multi-turn RL, and sandbox rollout infrastructure.(arxiv.org)
State Of The Art
Computer-use benchmarks are improving fast, but real reliability is still weak. Original OSWorld exposed the gap: humans completed 72.36% while the best model in that paper got 12.24%, mainly struggling with GUI grounding and operational knowledge.(arxiv.org) OSWorld 2.0, published June 28, 2026, is harsher: 108 long-horizon workflows, median human time about 1.6 hours, and the best reported agent only completes 20.6% under binary completion. The failure modes are constraints, dynamic info, hidden state, guessing, and skipped verification.(arxiv.org)
So the winning hack posture is not “my agent can do anything.” It is: “I picked a painful UI workflow, constrained it, instrumented it, verified it, and made failures legible.”
H Company Stack
H gives you three useful layers:
Managed Computer-Use Agents: H provisions a cloud browser, runs a Holo-powered agent, and gives you a session lifecycle you can monitor, steer, pause, cancel, and replay. Use h/web-surfer-flash for the fastest start.(hub.hcompany.ai)

Models API: OpenAI-compatible endpoint at https://api.hcompany.ai/v1/. Current served models are holo3-1-35b-a3b and holo3-122b-a10b; both accept text/images and structured outputs. The 35B is fast/free-tier/open-weight and supports native function calling; the 122B is maximum performance/API-only and lacks native function calling.(hub.hcompany.ai)

HoloDesktop CLI / local desktop: local runtime controls the visible desktop: apps, mouse, keyboard, screen. On Windows, install with irm https://install.hcompany.ai/install.ps1 | iex, then holo login, then holo run "...". It can hijack your real foreground desktop, so use Esc twice, Ctrl+C, or holo stop to kill a run, and set --max-steps / --max-time-s.(hub.hcompany.ai)

Key H Concepts
Use these correctly:
Agent: reusable config: model, environment, instructions, skills, tools, structured answer format.(hub.hcompany.ai)
Environment: what the agent sees/acts on. Managed API mainly has browser today; local desktop/browser exists through Python SDK / CLI.(hub.hcompany.ai)
Session: one run with statuses like queued, running, idle, completed, failed, timed_out; use latest_answer, changes, and events for results/debugging.(hub.hcompany.ai)
Skills: Markdown instruction fragments loaded only when their description matches the task. Make descriptions trigger-specific.(hub.hcompany.ai)
Custom tools: your Python/TS functions the agent can call for APIs, DBs, deterministic checks, etc. Make side-effecting tools idempotent because execution is at-least-once.(hub.hcompany.ai)
Structured output: use JSON Schema/Pydantic/Zod so your demo returns judge-friendly typed results instead of prose.(hub.hcompany.ai)
Raw Model Loop Gotchas
If you use the Models API directly, follow H’s harness conventions exactly: normalized coordinates are [0,1000], keep only the last 3 screenshots in context, preserve durable memory in note/assistant content, and do not mix structured-output format with native function-calling format. H explicitly says skipping these conventions hurts quality.(hub.hcompany.ai) For simple grounding, use element localization: screenshot + element description -> {x,y}.(hub.hcompany.ai)
Where H Is Lacking Right Now
Managed cloud agents are browser-first today; full remote desktop VMs are listed as future work, not current default.(hub.hcompany.ai)
Local browser/desktop control is Python-SDK/CLI centered; TypeScript is not equal there yet.(hub.hcompany.ai)
Local desktop shares your real visible machine and one local session at a time; background app binding is future work.(hub.hcompany.ai)
Vaults are only 1Password today and cloud-browser only; local runs rely on your local profile/logins.(hub.hcompany.ai)
The action surface is fixed per environment; you can add custom tools, but not finely remove built-in click/type/etc.(hub.hcompany.ai)
Benchmarks are not product reliability. Even Holo3’s claimed 78.85% on OSWorld-Verified still implies failures, and OSWorld2.0 shows long workflows remain far from solved.(hcompany.ai)
Fastest Hack Path
Use managed h/web-surfer-flash for browser demos. Use HoloDesktop/local desktop only if the demo truly needs native apps/files.
Starter commands:
pip install "hai-agents[cli,browser,desktop]"
$env:HAI_API_KEY="hk-..."
hai run "Find the top 3 stories on Hacker News and return title, URL, and points" --agent h/web-surfer-flash
For desktop:
irm https://install.hcompany.ai/install.ps1 | iex
holo login
holo run --max-steps 25 "Open Notepad and write a short checklist for this hack demo"
Best project shape: a narrow, useful workflow with visible UI action, structured output, replayable Agent View/logs, and a deterministic verifier. That scores better than a broad assistant that sometimes works.


Friday 10:29 PM






Im gonna need more detail and simpler explanations here backed with real evidence, you are using a lot of jargon words:
Modern computer-use agents are moving from “general VLM + prompt” to “native GUI/action models.” Holo, UI-TARS, OpenAI CUA-style systems, and Claude Computer Use-style systems are trained on screen-action trajectories, UI grounding, multi-step workflows, and tool outputs. H’s own Holo3 post says their edge comes from synthetic navigation data, out-of-domain augmentation, curated RL, and synthetic enterprise environments.(hcompany.ai) UI-TARS-2 similarly frames SOTA GUI agents as unified perception, reasoning, memory, action, multi-turn RL, and sandbox rollout infrastructure.(arxiv.org)






Friday 10:34 PM






Worked for 1m 22s



You’re right. Simpler version:
A normal VLM can look at a screenshot and describe it. A computer-use agent has to look at the screenshot, choose an action, click/type/scroll, see what changed, and keep going until the job is done.
So when I said “native GUI/action models,” I meant: models trained or wired to use screens directly, not just talk about screens.
The Claim, In Plain English
Old/simple pattern:
“Here is a screenshot. What should I do?”
Better/current pattern:
“Here is a screenshot. Return the next exact action as data: click here, type this, scroll there, or answer. I will run that action, show you the new screen, and you decide the next action.”
That repeating cycle is what makes it an agent.
What Makes A VLM Agentic
A VLM becomes agentic when it has these extra pieces around it:
Eyes: screenshots or page state.
Hands: click, type, scroll, keypress, file, browser, shell tools.
A loop: act, observe result, act again.
Memory: remember useful facts from earlier screens.
A stop condition: know when to return the final answer.
Guardrails: max steps, human approval, sandbox, logs.
H’s own agent-loop docs say Holo is trained for a multi-step harness with screenshots, tool results, coordinate rules, and output format. They explicitly warn that skipping those conventions hurts quality: H agent loop docs.
Terms Translated
VLM: vision-language model. It reads images plus text.
GUI: graphical user interface. Buttons, forms, menus, tabs, desktop apps.
UI grounding: finding the actual place to click. Example: “the Sign in button” becomes coordinates like {x: 842, y: 120}. H has a dedicated element-localization mode for this: H element localization.
Screen-action trajectory: a training example like:
screen 1 -> click search box -> screen 2 -> type query -> screen 3 -> click result -> final answer.
Tool output: after the model clicks or types, the system sends back what happened. Usually a new screenshot, page state, or command result.
RL: reinforcement learning. The model tries actions in tasks, gets rewarded when it succeeds, and training pushes it toward better behavior.
Sandbox: an isolated browser/desktop where the model can safely act without touching your real accounts/files unless you allow it.
Evidence From H
H’s Models API docs say Holo models are trained to operate real UIs across web, desktop, and mobile, and return structured outputs you can execute: H Models API overview.
H’s Holo3 post says their training uses synthetic navigation examples, out-of-domain augmentation, data filtering, and reinforcement learning. In plain terms: they generate many fake-but-realistic UI tasks, vary them, filter them, and train the model to complete them: Holo3 post.
H also says Holo3 was trained in synthetic enterprise environments and evaluated on 486 multi-step tasks across e-commerce, business software, collaboration, and multi-app workflows. That is evidence they are not just prompting a generic VLM; they are training around work-like UI tasks.
Evidence From OpenAI CUA
OpenAI describes CUA as combining vision with reasoning through reinforcement learning, trained to interact with GUIs like buttons, menus, and fields. They also say it can break tasks into multi-step plans and self-correct: OpenAI Computer-Using Agent.
That supports the same pattern: screen understanding plus action generation plus repeated correction.
Evidence From Claude Computer Use
Anthropic’s docs define computer use as screenshot capture plus mouse and keyboard control. They describe the agent loop as: Claude asks for a tool action, your app runs it, returns the result, and Claude continues until done: Claude computer use docs.
Anthropic’s research post also says they had to train Claude to interpret screenshots and count pixels for cursor movement. They also admit it remains slow and error-prone: Anthropic computer use model.
Evidence From UI-TARS
The UI-TARS-2 paper describes GUI agents as models that combine perception, reasoning, action, and memory. It says their action space includes GUI operations like clicks, typing, and scrolling, plus extra tools like terminals and APIs. It also says they use multi-turn RL and sandbox rollouts for training: UI-TARS-2 paper.
Plain English: UI-TARS is trained not only to “see” the UI, but to repeatedly operate it.
Clean Rewrite Of My Original Sentence
The best computer-use systems are no longer just generic image models with a clever prompt. They are trained and engineered to operate software step by step: look at the screen, choose a click/type/scroll action, run it, inspect the result, remember important details, and continue. Holo, OpenAI CUA, Claude Computer Use, and UI-TARS all document some version of this loop.


Friday 10:35 PM






I do not understand the technical terms being used here, define them clearly use credible sources and then reexplain what the current state of H is to me and ground it in reality. You are not doing a proper gap analysis, you are supposed to dig deep into the so what? For example,  just telling me that Typescript is not supported is not intuitive, my question will be "why is this a problem when python is already supported anyway?"
Where H Is Lacking Right Now
Managed cloud agents are browser-first today; full remote desktop VMs are listed as future work, not current default.(hub.hcompany.ai)
Local browser/desktop control is Python-SDK/CLI centered; TypeScript is not equal there yet.(hub.hcompany.ai)
Local desktop shares your real visible machine and one local session at a time; background app binding is future work.(hub.hcompany.ai)
Vaults are only 1Password today and cloud-browser only; local runs rely on your local profile/logins.(hub.hcompany.ai)
The action surface is fixed per environment; you can add custom tools, but not finely remove built-in click/type/etc.()
Benchmarks are not product reliability. Even Holo3’s claimed 78.85% on OSWorld-Verified still implies failures, and OSWorld2.0 shows long workflows remain far from solved.()




Show more

Friday 10:39 PM






Worked for 3m 59s



You are right. My earlier answer skipped too many steps.
Plain Definitions
VLM: a vision-language model. It takes text plus images as input. H calls Holo a VLM and says it accepts text/images and returns structured outputs: H Models API.
GUI / UI: the visual software interface: buttons, menus, text fields, windows. OpenAI describes CUA as trained to interact with GUIs like buttons, menus, and text fields: OpenAI CUA.
Computer-use agent: software that sees a screen and chooses actions like click, type, scroll. H defines it almost exactly this way: H Computer-Use Agents.
Agent loop: repeat: observe screen -> choose action -> run action -> observe new screen. Anthropic explicitly calls this repeated tool-use cycle the “agent loop”: Claude computer use.
Grounding: turning “click the sign-in button” into actual screen coordinates. H’s element localization does exactly this: screenshot + element description -> {x, y}: H element localization.
Tool/action: an operation outside the model. For H browser agents, tools include navigate, click, type, scroll, wait, etc.: H browser actions.
Session: one run of an agent on one task. It has states like running, completed, failed, timed_out: H sessions.
Environment: the place the agent acts: a cloud browser, local Chrome, or local desktop. H’s docs say environment means what the agent sees and acts on: H environments.
Structured output: instead of prose, the agent returns JSON that your code can validate. This matters because demos need reliable fields, not paragraphs: H structured output.
Benchmark: a standardized test suite. OSWorld tests agents on real computer tasks. Original OSWorld found humans at 72.36% and the best model at 12.24%: OSWorld paper.
What Makes A VLM Agentic
A VLM alone can say: “I see a login button.”
An agent can say: “I will click the login button,” then actually click it, see the new screen, and decide the next step.
So “agentic” is not magic. It means the model is inside a loop with tools and state. Better computer-use models are trained for that loop, not just prompted into it. H says Holo is trained for a specific multi-step harness and warns that skipping its conventions hurts quality: H agent loop.
H Company Today
As of the live docs I checked, H has three practical layers:
Managed browser agents: easiest path. H hosts a browser, runs the agent, gives you session logs, replay, pause/cancel, structured answers. Best for hackathon web tasks.

Raw Holo models API: lower-level. You build the loop yourself. Current served models are holo3-1-35b-a3b and holo3-122b-a10b. The 35B supports native function calling; the 122B does not: H models.

Local desktop/browser control: the agent can control your real machine. Useful for native apps, but riskier and less clean for demos: H local desktop, HoloDesktop CLI.

Real Gap Analysis
Managed H is browser-first.
Evidence: H says agents run in a cloud browser today; remote desktop VMs are future roadmap.
So what: if your idea needs Excel, Photoshop, desktop files, multi-window OS workflows, or native apps, the managed cloud product does not give you a clean hosted desktop yet.
Hack implication: pick a browser workflow unless native desktop is central to the idea.

Local desktop controls your real visible machine.
Evidence: H warns HoloDesktop can open apps, switch focus, click, type, and read whatever is on screen.
So what: this is not a clean background worker. It can interrupt you, expose private windows, and make demos nondeterministic.
Hack workaround: use a clean Windows profile, close everything sensitive, set --max-steps / --max-time-s, and have a recorded fallback.

“Python-only local control” matters even if Python exists.
The problem is not that Python is bad. The problem is integration friction.
If your app is Next.js/TypeScript, local desktop control through Python means you need a sidecar Python process, process supervision, logs across runtimes, error handling across boundaries, and packaging for users.
For a hackathon, this is acceptable. For a polished product demo, it adds failure points.
Important nuance: TypeScript is supported for normal cloud sessions. The gap is local browser/desktop auto-control, where H says Python SDK is the only SDK with local control today: local browser docs.

The agent’s “completed” status is not proof.
Evidence: H says a session can end completed and still not have done what you asked; outcome is the agent’s self-assessment, not ground truth: observe and steer.
So what: judges may see a nice answer that is wrong.
Hack workaround: add a verifier. Check the final page, DOM, file, API response, screenshot, or saved artifact.

Auth is still awkward.
Vaults support 1Password and only cloud-hosted browsers. Local runs use local profiles/cookies instead: H vaults.
So what: login-heavy demos can fail on credentials, MFA, expired sessions, or profile state.
Hack workaround: use public flows, test accounts, browser profiles, or keep the demo post-login.

Tool permissions are coarse.
H says each environment has a fixed action set; you cannot add/remove individual built-in click/type/scroll actions.
So what: you cannot hard-restrict an agent to “read-only except this one button” at the environment-tool level.
Hack workaround: sandbox the environment and use narrow instructions plus human approval for risky steps.

Raw model loops are easy to get subtly wrong.
H warns coordinate scaling, screenshot history, message roles, and output format all affect quality.
So what: building your own harness can waste the hackathon.
Hack recommendation: use H’s managed agents first. Only build raw Holo loops if your core project is the harness itself.

Benchmarks are promising, not reliability guarantees.
H claims 78.85% on OSWorld-Verified for Holo3: Holo3. But OSWorld2.0 says current agents still fail long workflows, especially hidden state, constraints, dynamic info, guessing, and skipped verification: OSWorld2.0.
So what: do not pitch “general computer worker.” Pitch a constrained workflow with visible verification.

Best practical hackathon move: build a browser-first agent workflow, use H’s managed sessions, return structured output, show Agent View replay, and add one deterministic verifier. That directly targets technicality, demo quality, and sponsor alignment.


Friday 10:43 PM






teach me more about the python SDK and give me the link where you saw this, so there is no other way to control the agent locally other than Python is what you are saying?






Friday 10:51 PM






Worked for 59s



No, the precise statement is:
For H’s Computer-Use Agents “local browser/local desktop” SDK path, H says Python is the only SDK with local control today.
Source: local browser docs say “Python SDK (the only SDK with local control today)” here: https://hub.hcompany.ai/computer-use-agents/browser/local-control. Local desktop docs say the same here: https://hub.hcompany.ai/computer-use-agents/desktop/local-control.
But that does not mean Python is the only way to run anything locally.
The Real Breakdown
Cloud browser agents: Python, TypeScript, CLI, raw HTTP all work.
Local browser / local desktop through the H Agents SDK: first-class local-control SDK is Python today.
Local control without writing Python: possible through CLI commands like hai local browser, hai local desktop, and HoloDesktop CLI holo run.
TypeScript app controlling local desktop directly: not first-class in H’s docs right now. You’d likely call a Python/CLI sidecar from Node, or build your own harness against the raw Holo Models API.
H’s SDK page says they have typed Python and TypeScript clients, but TypeScript is described for sessions, agents, skills, environments, schedules, and webhooks, not local device auto-bridging: https://hub.hcompany.ai/computer-use-agents/sdks.
Python SDK Basics
Install:
pip install hai-agents
For local browser:
pip install "hai-agents[browser]"
For local desktop:
pip install "hai-agents[desktop]"
Authenticate:
$env:HAI_API_KEY="hk-..."
Simple cloud browser run:
from hai_agents import Client

client = Client()

result = client.run_session(
    agent="h/web-surfer-flash",
    messages="Open Hacker News and summarize the top story.",
)

print(result.status)
print(result.answer)
run_session(...) means: create the session, wait until it finishes, return the answer.
Local Browser Example
This lets the H agent drive Chrome on your machine:
from hai_agents import Client

client = Client()

agent = client.agents.create_agent(
    name="local-web",
    description="Drives a browser on my own machine.",
    environments=[
        {
            "id": "my-laptop",
            "kind": "web",
            "host": "user_device",
        }
    ],
)

result = client.run_session(
    agent=agent,
    messages="Open news.ycombinator.com and summarize the top story.",
)

print(result.status, result.answer)
Important details from H’s docs:
The SDK launches or attaches to Chrome.
It uses Chrome remote debugging port 9222.
If it launches Chrome itself, it uses a separate profile at ~/.hai/chrome-profile.
One Python process drives one local browser at a time.
Source: https://hub.hcompany.ai/computer-use-agents/browser/local-control.
Local Desktop Example
This lets the agent control your real mouse, keyboard, screen, files, and apps:
from hai_agents import Client

client = Client()

agent = client.agents.create_agent(
    name="local-desktop",
    description="Drives the desktop on my own machine.",
    environments=[
        {
            "id": "my-laptop",
            "kind": "desktop",
            "host": "user_device",
        }
    ],
)

result = client.run_session(
    agent=agent,
    messages="Open Notepad and write a short checklist for the demo.",
)

print(result.status, result.answer)
Source: https://hub.hcompany.ai/computer-use-agents/desktop/local-control.
CLI Alternative
If you do not want Python code, H also documents CLI local serving:
pip install "hai-agents[cli,desktop]"
hai local desktop
Then from another terminal:
hai run "Open Notepad and write a checklist" --agent local-desktop -o 'agent.environments[kind=desktop].session_id=<printed id>'
There is also HoloDesktop CLI:
holo run "Open Calculator and compute 12 percent of 4800"
That controls the visible desktop through a local runtime. Source: https://hub.hcompany.ai/holo-desktop-cli.
So for your hack: use Python if you want the least friction local-control integration. Use TypeScript if you stay with cloud browser agents. Use CLI/HoloDesktop if you want local desktop control without building a Python app.


Friday 10:52 PM






what is an SDK






Friday 10:56 PM






An SDK is a Software Development Kit.
Plain English: it is a package a company gives developers so they can use the company’s product from code without manually building every API request themselves.
For H Company, the SDK is the hai-agents package.
Without SDK, you manually call HTTP:
curl -X POST https://agp.eu.hcompany.ai/api/v2/sessions ...
With SDK, you write normal Python:
from hai_agents import Client

client = Client()
result = client.run_session(
    agent="h/web-surfer-flash",
    messages="Find the top story on Hacker News",
)

print(result.answer)
The SDK handles boring details like authentication, request formatting, polling the session until it finishes, parsing responses, and sometimes running local browser/desktop drivers.
So: API = the service endpoint. SDK = the convenient code library for using that API.


Friday 10:56 PM